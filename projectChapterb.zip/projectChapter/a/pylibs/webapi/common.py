def fun1():
    pass
