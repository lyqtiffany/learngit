'''
@author: haiwen
@date: 2021/2/26
@file: common.py
'''
def fun1():
    pass