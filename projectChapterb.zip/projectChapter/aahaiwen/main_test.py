'''
@author: haiwen
@date: 2021/2/26
@file: main_test.py.py
'''
import pytest

if __name__ == '__main__':
    pytest.main(['-s','--alluredir=tmp/report'])