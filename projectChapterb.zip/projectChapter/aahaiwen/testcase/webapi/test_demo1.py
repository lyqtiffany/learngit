'''
@author: haiwen
@date: 2021/2/26
@file: test_demo1.py
'''
import pytest
from pylibs.webapi.common import fun1

def test_fun():
    fun1()
    print('执行项目测试用例')



